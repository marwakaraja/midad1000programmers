﻿CREATE TABLE [dbo].[exams] (
    [id]              INT      IDENTITY (1, 1) NOT NULL,
    [date]            DATETIME NOT NULL,
    [numberofstudent] INT      NULL,
    [highgrade]       INT      DEFAULT ((100)) NULL,
    [period]          INT      NOT NULL,
    [result]          INT      NOT NULL,
    [contentId]       INT      NULL,
    [accountId]       INT      NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    FOREIGN KEY ([accountId]) REFERENCES [dbo].[account] ([id]),
    FOREIGN KEY ([contentId]) REFERENCES [dbo].[contents] ([id])
);

