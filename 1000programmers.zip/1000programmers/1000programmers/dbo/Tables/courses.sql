﻿CREATE TABLE [dbo].[courses] (
    [id]        INT          NOT NULL,
    [name]      VARCHAR (20) NULL,
    [datestart] DATETIME     NOT NULL,
    [dateend]   DATETIME     NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    UNIQUE NONCLUSTERED ([name] ASC)
);

