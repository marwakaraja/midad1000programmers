﻿CREATE TABLE [dbo].[contents] (
    [id]       INT          NOT NULL,
    [name]     VARCHAR (20) NULL,
    [courseId] INT          NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    FOREIGN KEY ([courseId]) REFERENCES [dbo].[courses] ([id]),
    UNIQUE NONCLUSTERED ([name] ASC)
);

