﻿CREATE TABLE [dbo].[filteredlearnersforworks] (
    [id]             INT IDENTITY (1, 1) NOT NULL,
    [attendancerate] INT NOT NULL,
    [resultofexams]  INT NOT NULL,
    [ruleforworkId]  INT NULL,
    [learnertId]     INT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    FOREIGN KEY ([learnertId]) REFERENCES [dbo].[learners] ([id]),
    FOREIGN KEY ([ruleforworkId]) REFERENCES [dbo].[rulesforwork] ([id])
);

