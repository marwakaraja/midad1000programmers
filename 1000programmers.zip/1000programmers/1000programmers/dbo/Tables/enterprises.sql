﻿CREATE TABLE [dbo].[enterprises] (
    [id]             INT               IDENTITY (1, 1) NOT NULL,
    [name]           VARCHAR (50)      NOT NULL,
    [location]       [sys].[geography] NOT NULL,
    [dateofcreation] DATETIME          DEFAULT ('01-01-2000') NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    UNIQUE NONCLUSTERED ([name] ASC)
);

