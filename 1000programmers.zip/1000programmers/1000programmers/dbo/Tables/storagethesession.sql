﻿CREATE TABLE [dbo].[storagethesession] (
    [id]          INT          NOT NULL,
    [name]        VARCHAR (20) NULL,
    [datesession] DATETIME     NOT NULL,
    [timesession] TIME (7)     NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    UNIQUE NONCLUSTERED ([name] ASC)
);

