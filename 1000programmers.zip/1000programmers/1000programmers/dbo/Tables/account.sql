﻿CREATE TABLE [dbo].[account] (
    [id]        INT          IDENTITY (1, 1) NOT NULL,
    [username]  VARCHAR (50) NOT NULL,
    [password]  VARCHAR (50) NOT NULL,
    [email]     VARCHAR (50) NOT NULL,
    [usreimage] VARCHAR (50) DEFAULT ('./image/default.png') NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    UNIQUE NONCLUSTERED ([email] ASC),
    UNIQUE NONCLUSTERED ([password] ASC),
    UNIQUE NONCLUSTERED ([username] ASC)
);

