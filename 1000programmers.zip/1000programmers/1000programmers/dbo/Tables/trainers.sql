﻿CREATE TABLE [dbo].[trainers] (
    [id]             INT          IDENTITY (1, 1) NOT NULL,
    [firstname]      VARCHAR (20) NOT NULL,
    [lastname]       VARCHAR (20) NOT NULL,
    [date]           DATETIME     NOT NULL,
    [age]            INT          NOT NULL,
    [specialization] VARCHAR (20) NOT NULL,
    [accountId]      INT          NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    CHECK ([age]>(25)),
    FOREIGN KEY ([accountId]) REFERENCES [dbo].[account] ([id])
);

