﻿CREATE TABLE [dbo].[experiencoftrainers] (
    [id]                      INT          IDENTITY (1, 1) NOT NULL,
    [experience]              VARCHAR (20) NOT NULL,
    [numberyearsofexperience] INT          NOT NULL,
    [trainerId]               INT          NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    FOREIGN KEY ([trainerId]) REFERENCES [dbo].[trainers] ([id])
);

