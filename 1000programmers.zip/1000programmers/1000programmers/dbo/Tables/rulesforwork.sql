﻿CREATE TABLE [dbo].[rulesforwork] (
    [id]                      INT          IDENTITY (1, 1) NOT NULL,
    [experience]              VARCHAR (20) NOT NULL,
    [numberyearsofexperience] INT          NOT NULL,
    [salary]                  INT          NOT NULL,
    [enterpriseId]            INT          NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    FOREIGN KEY ([enterpriseId]) REFERENCES [dbo].[enterprises] ([id])
);

