﻿CREATE TABLE [dbo].[learners] (
    [id]             INT          IDENTITY (1, 1) NOT NULL,
    [firstname]      VARCHAR (20) NOT NULL,
    [lastname]       VARCHAR (20) NOT NULL,
    [birthdate]      DATETIME     NOT NULL,
    [age]            INT          NOT NULL,
    [universityname] VARCHAR (20) NOT NULL,
    [isgratuated]    BIT          NOT NULL,
    [accountId]      INT          NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    CHECK ([age]<(30)),
    FOREIGN KEY ([accountId]) REFERENCES [dbo].[account] ([id])
);

