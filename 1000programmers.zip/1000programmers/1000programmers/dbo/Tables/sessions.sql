﻿CREATE TABLE [dbo].[sessions] (
    [id]                INT         IDENTITY (1, 1) NOT NULL,
    [name]              VARCHAR (1) NOT NULL,
    [date]              DATETIME    NOT NULL,
    [period]            INT         NOT NULL,
    [accountId]         INT         NULL,
    [contentId]         INT         NULL,
    [stroragesessionId] INT         NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    FOREIGN KEY ([accountId]) REFERENCES [dbo].[account] ([id]),
    FOREIGN KEY ([contentId]) REFERENCES [dbo].[contents] ([id]),
    FOREIGN KEY ([stroragesessionId]) REFERENCES [dbo].[storagethesession] ([id])
);

