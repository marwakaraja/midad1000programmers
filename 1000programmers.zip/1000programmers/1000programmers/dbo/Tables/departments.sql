﻿CREATE TABLE [dbo].[departments] (
    [id]                        INT          IDENTITY (1, 1) NOT NULL,
    [name]                      VARCHAR (50) NOT NULL,
    [numberofRequiredEmployees] INT          NOT NULL,
    [salary]                    INT          NOT NULL,
    [enterpriseId]              INT          NULL,
    PRIMARY KEY CLUSTERED ([id] ASC),
    FOREIGN KEY ([enterpriseId]) REFERENCES [dbo].[enterprises] ([id]),
    UNIQUE NONCLUSTERED ([name] ASC)
);

